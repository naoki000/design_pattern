public class FileTreatmentException extends RuntimeException {      // RuntimeException�Ő��������H
    public FileTreatmentException() {
    }
    public FileTreatmentException(String msg) {
        super(msg);
    }
}
