public class LivenessException extends RuntimeException {
    public LivenessException(String msg) {
        super(msg);
    }
}
