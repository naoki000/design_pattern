package searcher;

public interface Display {
    public abstract void display(String line);
}
