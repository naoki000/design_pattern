package searcher;

public abstract class Searcher {
    public abstract void search(String word, Display display);
}
